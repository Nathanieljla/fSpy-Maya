""" Loader for Maya api sub-package """
from __future__ import absolute_import
from __future__ import print_function
from __future__ import division
# this can be imported without having maya fully initialized
from .allapi import *
